export async function validarSesion() {
    if (!localStorage.getItem("correo")) {
        return;
    }
    let status = 201;
    await fetch('http://localhost:8080/api/cliente/validar?correo='+localStorage.getItem("correo"), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
    }).then((res) => {
        if (res.status == 200) {
            return res.json();
        } else {
            status = 400;
            return res.text()
        }
    })
    .then(resp => {
        if (status != 201) {
            localStorage.removeItem("correo");
            return;
        } 
        document.querySelector("#liCuenta").classList.remove("d-none");
        document.querySelector("#liLogin").classList.add("d-none");
    })
    .catch(error => localStorage.removeItem("correo"));
}

export async function registrarCliente(cliente) {
    let status = 201;
    await fetch('http://localhost:8080/api/cliente/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(cliente)
    }).then((res) => {
        if (res.status == 201) {
            return res.json();
        } else {
            status = 400;
            return res.text()
        }
    })
    .then(resp => {
        if (status != 201) {
            mostrarToast("registro", resp);
            localStorage.removeItem("correo");
            return;
        } 
        localStorage.setItem("correo",resp.correo);
        location.reload();
    });
}

export async function loginCliente(cliente) {
    let status = 201;
    await fetch('http://localhost:8080/api/cliente/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(cliente)
    }).then((res) => {
        if (res.status == 200) {
            return res.json();
        } else {
            status = 400;
            return res.text()
        }
    })
    .then(resp => {
        if (status != 201) {
            mostrarToast("login", resp);
            return;
        } 
        localStorage.setItem("correo",resp.correo);
        location.reload();
    });
}

// Toast
function mostrarToast(tipo, mensaje, color) {
    switch(tipo){
        case "password":
            generarToast("Contraseñas no coinciden", "danger");
            break;
        case "registro":
            generarToast(mensaje, "warning");
            break;
        case "login":
            generarToast(mensaje, "warning");
            break;
    }
    const toast = new bootstrap.Toast(document.querySelector(".toast"));
    toast.show();
}

function generarToast(mensaje, color){
    const toast = `
    <div class="toast align-items-center text-bg-${color} border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">${mensaje}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
    `;
    document.querySelector("#responseToast").innerHTML = toast;
}