import { Cliente } from "./obj/Cliente.js";
import { validarSesion, registrarCliente, loginCliente } from './auth.js';
import { Producto } from "./obj/Producto.js";

validarSesion();

const products = await getProducts().then(res => (res.status == 200)? res.json(): false).catch(error => false);

if (products) {
    document.querySelector("#cantResults").innerText = products.length;

    products.sort((i, j) => j.ratio - i.ratio);
    mostrarCards(products);

    document.querySelector("#sOrder").addEventListener('change',(e) => {
        switch(e.target.value) {
            case "0":
                console.log("hola");
                products.sort((i, j) => j.ratio - i.ratio);
                break;
            case "1":
                products.sort((i, j) => i.precio - j.precio);
                break;
            case "2":
                products.sort((i, j) => j.precio - i.precio);
                break;
            case "3":
                products.sort((i, j) => i.nombre.localeCompare(j.nombre));
                break;
            case "4":
                products.sort((i, j) => j.nombre.localeCompare(i.nombre));
                break;
        }
        mostrarCards(products);
    });
}

// Validacion
document.querySelector("#fRegister").addEventListener("submit",(e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    if (data.get("irRePassword") !== data.get("irPassword") ) {
        mostrarToast("password");
        return;
    }
    const cliente = new Cliente();
    cliente.dni = data.get("irDocumento");
    cliente.nombres = data.get("irNombre");
    cliente.direccion = data.get("irDireccion");
    cliente.correo = data.get("irCorreo");
    cliente.password = data.get("irPassword");

    registrarCliente(cliente);
});

document.querySelector("#fLogin").addEventListener("submit",async(e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    const cliente = new Cliente();
    cliente.correo = data.get("iCorreo");
    cliente.password = data.get("iPassword");

    loginCliente(cliente);
});

document.querySelector("#liLogout").addEventListener("click",() => {
    localStorage.removeItem("correo");
    location.reload();
})

// Form Login
document.querySelector("#btnNextBody").addEventListener('click',() => {
    document.querySelector("#bodyLogin").classList.add("d-none");
    document.querySelector("#bodyRegister").classList.remove("d-none");
});

document.querySelector("#btnAfterBody").addEventListener('click',() => {
    document.querySelector("#bodyRegister").classList.add("d-none");
    document.querySelector("#bodyLogin").classList.remove("d-none");
});

// Items Product
async function getProducts() {
    return fetch('http://localhost:8080/api/producto', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
}

function mostrarCards(products) {
    let html = "";
    products.forEach((item) => {
        const producto = new Producto();
        producto.idProducto = item.idProducto;
        producto.nombre = item.nombre;
        producto.imagen = item.imagen;
        producto.descripcion = item.descripcion;
        producto.precio = item.precio;
        producto.stock = item.stock;

        html += producto.generarCard();
    });
    document.querySelector("#product-list").innerHTML = html;
    document.querySelectorAll("btn-quantity").forEach(btn=>{
        btn.addEventListener("click",e=>{
            console.log(e.target);
        });
    });
}

$(".item-plus").on('click',(e) => {
    const cant = parseInt(e.target.parentElement.children[1].value);
    const max = parseInt(e.target.parentElement.children[1].max);
    e.target.parentElement.children[1].value = (cant == max)? max:cant+1;
});

$(".item-minus").on('click',(e) => {
    const cant = parseInt(e.target.parentElement.children[1].value);
    const min = parseInt(e.target.parentElement.children[1].min);
    e.target.parentElement.children[1].value = (cant == min)? min:cant-1;
});

// Toast
function mostrarToast(tipo, mensaje, color) {
    switch(tipo){
        case "password":
            generarToast("Contraseñas no coinciden", "danger");
            break;
        case "registro":
            generarToast(mensaje, "warning");
            break;
        case "login":
            generarToast(mensaje, "warning");
            break;
    }
    const toast = new bootstrap.Toast(document.querySelector(".toast"));
    toast.show();
}

function generarToast(mensaje, color){
    const toast = `
    <div class="toast align-items-center text-bg-${color} border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">${mensaje}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
    `;
    document.querySelector("#responseToast").innerHTML = toast;
}