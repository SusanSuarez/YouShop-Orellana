document.querySelectorAll("btn-quantity").forEach(btn=>{
    btn.addEventListener("click",e=>{
        console.log(e.target);
    });
});